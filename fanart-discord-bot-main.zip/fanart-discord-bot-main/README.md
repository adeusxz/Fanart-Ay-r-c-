# fanart-discord-bot
a discord bot seperating fanarts
